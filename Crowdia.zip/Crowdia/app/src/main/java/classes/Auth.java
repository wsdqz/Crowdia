package classes;

public class Auth {
    public static User signedInUser = null;
}
